#include "acllib.h"
#include <stdio.h>



int Setup()
{
	initWindow("Test",DEFAULT,DEFAULT,800,600);
	
	initConsole();
	printf("hello\n");
	
	beginPaint();
	
    line(10,500,500,10);
    roundrect(500,200,500,300,988,734);
    line(500,10,500,10);
    line(10,10,10,500);
    line(10,10,500,10);
	line(10,10,500,500);
	line(500,10,500,500);
	line(500,500,10,500);
	
	endPaint();

	return 0;
}